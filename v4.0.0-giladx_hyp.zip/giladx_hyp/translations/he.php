<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{giladx_hyp}prestashop>giladx_hyp_bac8cf7cee418f5d2f45310b7f0ad9a3'] = 'לתשלום בכרטיס אשראי';
$_MODULE['<{giladx_hyp}prestashop>giladx_hyp_463f41b990c51c77af3eb7129e4c5b49'] = 'חתימה';
$_MODULE['<{giladx_hyp}prestashop>giladx_hyp_3f69828e62dbfc61a15d055ce4c325f2'] = 'מספר מסוף';
$_MODULE['<{giladx_hyp}prestashop>giladx_hyp_ca80b672f1885df82eacb661019bcd41'] = 'תשלומים';
$_MODULE['<{giladx_hyp}prestashop>giladx_hyp_43d86b2167e8a3464a552ee706d46d88'] = 'דחוי';
$_MODULE['<{giladx_hyp}prestashop>giladx_hyp_f827cf462f62848df37c5e1e94a4da74'] = 'כן';
$_MODULE['<{giladx_hyp}prestashop>giladx_hyp_f8320b26d30ab433c5a54546d21f414c'] = 'לא';
$_MODULE['<{giladx_hyp}prestashop>giladx_hyp_c9cc8cce247e49bae79f15173ce97354'] = 'שמור';
$_MODULE['<{giladx_hyp}prestashop>payment_infos_13221b034aa655f6b47fe56c94df497c'] = 'לתשלום מאובטח';
